document.addEventListener('DOMContentLoaded',()=>{
document.querySelector('#pickupBtn').addEventListener('click',()=>alert('Pickup service coming soon'));
document.querySelector('#contactScroll').addEventListener('click',()=>alert('Contact section'));
});